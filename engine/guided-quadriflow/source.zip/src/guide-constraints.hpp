// Independent experimental guide attachment. This is not upstream/native ZBrush.
#pragma once
#include "parametrizer.hpp"
#include <fstream>
#include <iomanip>
#include <algorithm>
#include <set>
#include <sstream>
#include <stdexcept>

namespace qflow {
struct GuideSegment { Vector3d a, b, normal; int curve; };

inline std::vector<int> attach_guides(Parametrizer& field, const std::string& file,
                                      double width, double orientation_weight,
                                      double position_weight, bool hard_edges=false) {
    if (!(width > 0) || orientation_weight < 0 || orientation_weight > 1 ||
        position_weight < 0 || position_weight > 1)
        throw std::runtime_error("Invalid guide width or weights");
    std::ifstream in(file);
    int count;
    if (!(in >> count) || count < 1 || count > 1000000)
        throw std::runtime_error("Invalid guide segment count");
    std::vector<GuideSegment> segments(count);
    for (auto& s: segments) {
        if (!(in >> s.curve >> s.a[0] >> s.a[1] >> s.a[2] >> s.b[0] >> s.b[1] >> s.b[2]
              >> s.normal[0] >> s.normal[1] >> s.normal[2]) ||
            !s.a.allFinite() || !s.b.allFinite() || !s.normal.allFinite() ||
            (s.b-s.a).norm() < 1e-12 || s.normal.norm() < .5)
            throw std::runtime_error("Invalid guide segment");
        s.a = (s.a-field.normalize_offset)/field.normalize_scale;
        s.b = (s.b-field.normalize_offset)/field.normalize_scale;
        s.normal.normalize();
    }
    auto& h = field.hierarchy;
    for (const auto& s:segments) {
        field.guide_a.push_back(s.a);field.guide_b.push_back(s.b);field.guide_ids.push_back(s.curve);
    }
    if (h.mCQw[0].size() == 0) h.clearConstraints();
    std::vector<int> owners(h.mV[0].cols(), -1);
    const double radius = width * field.scale;
    int attached = 0;
    for (int i=0; i<h.mV[0].cols(); ++i) {
        const Vector3d p=h.mV[0].col(i), n=h.mN[0].col(i);
        double best=radius*radius;
        int selected=-1;
        Vector3d nearest, tangent;
        for (int j=0; j<count; ++j) {
            const auto& s=segments[j];
            // A geometric support normal rejects the opposite side of a thin sheet.
            if (n.dot(s.normal)<.5) continue;
            Vector3d d=s.b-s.a;
            const double t=std::max(0.,std::min(1.,d.dot(p-s.a)/d.squaredNorm()));
            const Vector3d q=s.a+t*d;
            const double ds=(p-q).squaredNorm();
            if (ds>=best) continue;
            d-=n*n.dot(d);
            if (d.norm()<1e-12) continue;
            best=ds; selected=j; nearest=q; tangent=d.normalized();
        }
        if (selected<0) continue;
        // Existing exact boundary constraints take priority over nearby guides.
        if (h.mCQw[0][i] != 0) continue;
        h.mCQ[0].col(i)=tangent;
        h.mCO[0].col(i)=nearest;
        h.mCQw[0][i]=orientation_weight;
        h.mCOw[0][i]=position_weight;
        owners[i]=segments[selected].curve;
        ++attached;
    }
    if (hard_edges) {
        int tagged=0;
        const double tolerance=1e-8;
        for (int face=0;face<h.mF.cols();++face) for (int k=0;k<3;++k) {
            const Vector3d p=h.mV[0].col(h.mF(k,face)),q=h.mV[0].col(h.mF((k+1)%3,face));
            for (const auto& s: segments) {
                Vector3d d=s.b-s.a;
                double u=d.dot(p-s.a)/d.squaredNorm(),v=d.dot(q-s.a)/d.squaredNorm();
                if (u < -tolerance || v < -tolerance || u > 1+tolerance || v > 1+tolerance) continue;
                if ((p-s.a-u*d).norm()>tolerance || (q-s.a-v*d).norm()>tolerance) continue;
                field.sharp_edges[face*3+k]=1;
                ++tagged;break;
            }
        }
        printf("Embedded guide edges entering integer/extraction constraints: %d oriented edges\n",tagged);
        if (!tagged) throw std::runtime_error("No embedded guide edges found");
    }
    h.propagateConstraints();
    printf("Attached guide constraints: %d / %d, width=%g h, orientation=%g, position=%g\n",
           attached,(int)owners.size(),width,orientation_weight,position_weight);
    if (attached==0) throw std::runtime_error("No guide support vertices at this width");
    return owners;
}

// One constrained-edge list (ZRemesher collector 0x2889c0/0x28e230): rows `a b mode` of input
// file vertices that form a source edge. Read after Load and before Initialize, so the
// identities ride through the source subdivision.
//
//   mode  direction write  lattice line (registration)  preserved in integer solve/extraction
//    1         yes                  no                                no        native mode 1
//    2         yes                  yes                               yes       native mode 2
//    3         yes                  no                                yes       engine only
//    4         no                   no                                yes       engine only
//
// Modes 3 and 4 are not native modes. They keep what this engine did for preserved (sharp)
// edges before it had a lattice-line constraint.
//
// A row may end with a fourth number in (0, 1]: the largest face size at that edge as a fraction
// of the requested base size (see ComputeSizeCaps). It is the application's sizing request, not
// a native field.
inline int constrained_rank(int mode) { return mode == 2 ? 3 : mode == 3 ? 2 : mode == 4 ? 1 : 0; }
inline void read_constrained_edges(Parametrizer& field, const std::string& file) {
    std::ifstream in(file);
    int count;
    if (!(in >> count) || count < 1 || count > 4000000)
        throw std::runtime_error("Invalid constrained edge count");
    std::map<int, int> engine;
    for (int i = 0; i < (int)field.file_vertex.size(); ++i) engine[field.file_vertex[i]] = i;
    std::set<std::pair<int, int>> present;
    for (int f = 0; f < field.F.cols(); ++f)
        for (int k = 0; k < 3; ++k) {
            const int a = field.F(k, f), b = field.F((k + 1) % 3, f);
            present.insert(std::make_pair(std::min(a, b), std::max(a, b)));
        }
    std::string line;
    std::getline(in, line);
    int sized = 0;
    for (int i = 0; i < count; ++i) {
        int a, b, mode;
        double size = 0;
        if (!std::getline(in, line)) throw std::runtime_error("Invalid constrained edge");
        std::istringstream row(line);
        if (!(row >> a >> b >> mode) || mode < 1 || mode > 4 || !engine.count(a) || !engine.count(b) || a == b)
            throw std::runtime_error("Invalid constrained edge");
        if (row >> size) {
            if (!(size > 0) || size > 1) throw std::runtime_error("Invalid constrained edge size");
            ++sized;
        } else size = 0;
        Parametrizer::ConstrainedEdge edge{engine[a], engine[b], mode, size};
        const auto key = std::make_pair(std::min(edge.a, edge.b), std::max(edge.a, edge.b));
        if (!present.count(key)) throw std::runtime_error("A constrained edge is not a source mesh edge");
        // An edge listed twice keeps its later position and the stronger of its modes.
        auto old = field.constrained_tags.find(key);
        if (old != field.constrained_tags.end() && constrained_rank(field.constrained_edges[old->second].mode) > constrained_rank(edge.mode))
            edge.mode = field.constrained_edges[old->second].mode;
        // ... and the smaller of its sizes.
        if (old != field.constrained_tags.end() && field.constrained_edges[old->second].size > 0 &&
            (edge.size == 0 || field.constrained_edges[old->second].size < edge.size))
            edge.size = field.constrained_edges[old->second].size;
        field.constrained_tags[key] = (int)field.constrained_edges.size();
        field.constrained_edges.push_back(edge);
    }
    printf("Constrained edges: %d listed, %d distinct source edges\n", count, (int)field.constrained_tags.size());
    if (sized) printf("Constrained edge sizes: %d listed edges carry a face-size cap\n", sized);
}

// Directions and registration from the constrained edges, after Initialize.
//
// ZRemesher 0x2fc0c0 writes the normalized direction of every embedded edge to its incident
// source faces, in list order, later writes winning. This field lives on vertices, so the
// direction goes to the two end vertices of the edge (the way this engine already constrains
// boundary edges); nothing is locked by distance from the curve. Mode 2 adds the integer
// registration of 0x28b920 (flag and denominator 1) in this engine's terms: the vertex position
// is constrained to the edge line, which puts a lattice line on the edge, and the edge is
// marked for the integer solve and extraction as a preserved edge. Mode 1 edges direct the
// field only. Modes 3 and 4 (engine only) are preserved edges without the lattice line; mode 4
// writes no direction either. Boundary constraints, set earlier, are kept: this engine
// preserves boundaries exactly.
inline void attach_constrained_edges(Parametrizer& field) {
    auto& h = field.hierarchy;
    if (h.mCQw[0].size() == 0) h.clearConstraints();
    const auto& F = h.mF;
    field.constrained_modes.assign(F.cols() * 3, 0);
    std::vector<std::pair<int, std::pair<int, int>>> ordered;   // (list index, working edge)
    for (const auto& tag : field.constrained_tags) ordered.push_back(std::make_pair(tag.second, tag.first));
    std::sort(ordered.begin(), ordered.end());
    std::vector<char> boundary(h.mV[0].cols(), 0);
    for (int e = 0; e < 3 * F.cols(); ++e)
        if (h.mE2E[e] == -1) boundary[F(e % 3, e / 3)] = boundary[F((e + 1) % 3, e / 3)] = 1;
    int directed = 0, registered = 0, kept = 0;
    for (const auto& item : ordered) {
        const auto& listed = field.constrained_edges[item.first];
        const int a = item.second.first, b = item.second.second;
        Vector3d direction = h.mV[0].col(b) - h.mV[0].col(a);
        if (direction.norm() < 1e-14) continue;
        direction.normalize();
        if (listed.mode == 4) continue;
        for (int vertex : {a, b}) {
            if (boundary[vertex]) { ++kept; continue; }
            const Vector3d n = h.mN[0].col(vertex);
            Vector3d tangent = direction - n * n.dot(direction);
            if (tangent.norm() < 1e-12) continue;
            h.mCQ[0].col(vertex) = tangent.normalized();
            h.mCQw[0][vertex] = 1.0;
            ++directed;
            if (listed.mode == 2) {
                h.mCO[0].col(vertex) = h.mV[0].col(vertex);
                h.mCOw[0][vertex] = 1.0;
                ++registered;
            }
        }
    }
    int tagged = 0;
    for (int face = 0; face < F.cols(); ++face) for (int k = 0; k < 3; ++k) {
        const int a = F(k, face), b = F((k + 1) % 3, face);
        auto tag = field.constrained_tags.find(std::make_pair(std::min(a, b), std::max(a, b)));
        if (tag == field.constrained_tags.end()) continue;
        const int mode = field.constrained_edges[tag->second].mode;
        field.constrained_modes[face * 3 + k] = (unsigned char)mode;
        if (mode != 1) { field.sharp_edges[face * 3 + k] = 1; ++tagged; }
    }
    h.propagateConstraints();
    printf("Constrained edges after subdivision: %d working edges; %d direction writes, %d registered, %d boundary vertices kept; %d oriented edges enter integer/extraction constraints\n",
           (int)ordered.size(), directed, registered, kept, tagged);
}

inline void dump_guide_field(Parametrizer& field, const std::vector<int>& owners,
                            const std::string& file) {
    auto& h=field.hierarchy;
    std::ofstream out(file);
    if (!out) throw std::runtime_error("Cannot write field diagnostics");
    out << std::setprecision(17);
    out << "vertex,curve,x,y,z,nx,ny,nz,qx,qy,qz,cqx,cqy,cqz,qweight,pweight,ox,oy,oz\n";
    for (int i=0; i<h.mV[0].cols(); ++i) {
        Vector3d p=h.mV[0].col(i)*field.normalize_scale+field.normalize_offset;
        Vector3d o=h.mO[0].col(i)*field.normalize_scale+field.normalize_offset;
        Vector3d cq=Vector3d::Zero(); double qw=0,pw=0;
        if (h.mCQw[0].size()) { qw=h.mCQw[0][i]; pw=h.mCOw[0][i]; if (qw) cq=h.mCQ[0].col(i); }
        out << i << ',' << (owners.empty()?-1:owners[i]);
        for (int k=0;k<3;++k) out << ',' << p[k];
        for (int k=0;k<3;++k) out << ',' << h.mN[0](k,i);
        for (int k=0;k<3;++k) out << ',' << h.mQ[0](k,i);
        for (int k=0;k<3;++k) out << ',' << cq[k];
        out << ',' << qw << ',' << pw;
        for (int k=0;k<3;++k) out << ',' << o[k];
        out << '\n';
    }
}
}
