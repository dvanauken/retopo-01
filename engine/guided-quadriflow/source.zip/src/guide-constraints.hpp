// Independent experimental guide attachment. This is not upstream/native ZBrush.
#pragma once
#include "parametrizer.hpp"
#include <fstream>
#include <iomanip>
#include <stdexcept>

namespace qflow {
struct GuideSegment { Vector3d a, b, normal; int curve; };

inline std::vector<int> attach_guides(Parametrizer& field, const std::string& file,
                                      double width, double orientation_weight,
                                      double position_weight, bool hard_edges=false) {
    if (!(width > 0) || orientation_weight < 0 || orientation_weight > 1 ||
        position_weight < 0 || position_weight > 1)
        throw std::runtime_error("Invalid guide width or weights");
    std::ifstream in(file);
    int count;
    if (!(in >> count) || count < 1 || count > 1000000)
        throw std::runtime_error("Invalid guide segment count");
    std::vector<GuideSegment> segments(count);
    for (auto& s: segments) {
        if (!(in >> s.curve >> s.a[0] >> s.a[1] >> s.a[2] >> s.b[0] >> s.b[1] >> s.b[2]
              >> s.normal[0] >> s.normal[1] >> s.normal[2]) ||
            !s.a.allFinite() || !s.b.allFinite() || !s.normal.allFinite() ||
            (s.b-s.a).norm() < 1e-12 || s.normal.norm() < .5)
            throw std::runtime_error("Invalid guide segment");
        s.a = (s.a-field.normalize_offset)/field.normalize_scale;
        s.b = (s.b-field.normalize_offset)/field.normalize_scale;
        s.normal.normalize();
    }
    auto& h = field.hierarchy;
    for (const auto& s:segments) {
        field.guide_a.push_back(s.a);field.guide_b.push_back(s.b);field.guide_ids.push_back(s.curve);
    }
    if (h.mCQw[0].size() == 0) h.clearConstraints();
    std::vector<int> owners(h.mV[0].cols(), -1);
    const double radius = width * field.scale;
    int attached = 0;
    for (int i=0; i<h.mV[0].cols(); ++i) {
        const Vector3d p=h.mV[0].col(i), n=h.mN[0].col(i);
        double best=radius*radius;
        int selected=-1;
        Vector3d nearest, tangent;
        for (int j=0; j<count; ++j) {
            const auto& s=segments[j];
            // A geometric support normal rejects the opposite side of a thin sheet.
            if (n.dot(s.normal)<.5) continue;
            Vector3d d=s.b-s.a;
            const double t=std::max(0.,std::min(1.,d.dot(p-s.a)/d.squaredNorm()));
            const Vector3d q=s.a+t*d;
            const double ds=(p-q).squaredNorm();
            if (ds>=best) continue;
            d-=n*n.dot(d);
            if (d.norm()<1e-12) continue;
            best=ds; selected=j; nearest=q; tangent=d.normalized();
        }
        if (selected<0) continue;
        // Existing exact boundary constraints take priority over nearby guides.
        if (h.mCQw[0][i] != 0) continue;
        h.mCQ[0].col(i)=tangent;
        h.mCO[0].col(i)=nearest;
        h.mCQw[0][i]=orientation_weight;
        h.mCOw[0][i]=position_weight;
        owners[i]=segments[selected].curve;
        ++attached;
    }
    if (hard_edges) {
        int tagged=0;
        const double tolerance=1e-8;
        for (int face=0;face<h.mF.cols();++face) for (int k=0;k<3;++k) {
            const Vector3d p=h.mV[0].col(h.mF(k,face)),q=h.mV[0].col(h.mF((k+1)%3,face));
            for (const auto& s: segments) {
                Vector3d d=s.b-s.a;
                double u=d.dot(p-s.a)/d.squaredNorm(),v=d.dot(q-s.a)/d.squaredNorm();
                if (u < -tolerance || v < -tolerance || u > 1+tolerance || v > 1+tolerance) continue;
                if ((p-s.a-u*d).norm()>tolerance || (q-s.a-v*d).norm()>tolerance) continue;
                field.sharp_edges[face*3+k]=1;
                ++tagged;break;
            }
        }
        printf("Embedded guide edges entering integer/extraction constraints: %d oriented edges\n",tagged);
        if (!tagged) throw std::runtime_error("No embedded guide edges found");
    }
    h.propagateConstraints();
    printf("Attached guide constraints: %d / %d, width=%g h, orientation=%g, position=%g\n",
           attached,(int)owners.size(),width,orientation_weight,position_weight);
    if (attached==0) throw std::runtime_error("No guide support vertices at this width");
    return owners;
}

inline void dump_guide_field(Parametrizer& field, const std::vector<int>& owners,
                            const std::string& file) {
    auto& h=field.hierarchy;
    std::ofstream out(file);
    if (!out) throw std::runtime_error("Cannot write field diagnostics");
    out << std::setprecision(17);
    out << "vertex,curve,x,y,z,nx,ny,nz,qx,qy,qz,cqx,cqy,cqz,qweight,pweight,ox,oy,oz\n";
    for (int i=0; i<h.mV[0].cols(); ++i) {
        Vector3d p=h.mV[0].col(i)*field.normalize_scale+field.normalize_offset;
        Vector3d o=h.mO[0].col(i)*field.normalize_scale+field.normalize_offset;
        Vector3d cq=Vector3d::Zero(); double qw=0,pw=0;
        if (h.mCQw[0].size()) { qw=h.mCQw[0][i]; pw=h.mCOw[0][i]; if (qw) cq=h.mCQ[0].col(i); }
        out << i << ',' << (owners.empty()?-1:owners[i]);
        for (int k=0;k<3;++k) out << ',' << p[k];
        for (int k=0;k<3;++k) out << ',' << h.mN[0](k,i);
        for (int k=0;k<3;++k) out << ',' << h.mQ[0](k,i);
        for (int k=0;k<3;++k) out << ',' << cq[k];
        out << ',' << qw << ',' << pw;
        for (int k=0;k<3;++k) out << ',' << o[k];
        out << '\n';
    }
}
}
