#include <cstdlib>
#include <cstdio>
#include <set>
#include <string>
#include <algorithm>
#include "parametrizer.hpp"

namespace qflow {

void Parametrizer::ComputeInverseAffine()
{
    if (flag_adaptive_scale == 0)
        return;
    triangle_space.resize(F.cols());
#ifdef WITH_OMP
#pragma omp parallel for
#endif
    for (int i = 0; i < F.cols(); ++i) {
        Matrix3d p, q;
        p.col(0) = V.col(F(1, i)) - V.col(F(0, i));
        p.col(1) = V.col(F(2, i)) - V.col(F(0, i));
        p.col(2) = Nf.col(i);
        q = p.inverse();
        triangle_space[i].resize(2, 3);
        for (int j = 0; j < 2; ++j) {
            for (int k = 0; k < 3; ++k) {
                triangle_space[i](j, k) = q(j, k);
            }
        }
    }
}

void Parametrizer::EstimateSlope() {
    auto& mF = hierarchy.mF;
    auto& mQ = hierarchy.mQ[0];
    auto& mN = hierarchy.mN[0];
    auto& mV = hierarchy.mV[0];
    FS.resize(2, mF.cols());
    FQ.resize(3, mF.cols());
    for (int i = 0; i < mF.cols(); ++i) {
        const Vector3d& n = Nf.col(i);
        const Vector3d &q_1 = mQ.col(mF(0, i)), &q_2 = mQ.col(mF(1, i)), &q_3 = mQ.col(mF(2, i));
        const Vector3d &n_1 = mN.col(mF(0, i)), &n_2 = mN.col(mF(1, i)), &n_3 = mN.col(mF(2, i));
        Vector3d q_1n = rotate_vector_into_plane(q_1, n_1, n);
        Vector3d q_2n = rotate_vector_into_plane(q_2, n_2, n);
        Vector3d q_3n = rotate_vector_into_plane(q_3, n_3, n);
        
        auto p = compat_orientation_extrinsic_4(q_1n, n, q_2n, n);
        Vector3d q = (p.first + p.second).normalized();
        p = compat_orientation_extrinsic_4(q, n, q_3n, n);
        q = (p.first * 2 + p.second);
        q = q - n * q.dot(n);
        FQ.col(i) = q.normalized();
    }
    for (int i = 0; i < mF.cols(); ++i) {
        double step = hierarchy.mScale * 1.f;
        
        const Vector3d &n = Nf.col(i);
        Vector3d p = (mV.col(mF(0, i)) + mV.col(mF(1, i)) + mV.col(mF(2, i))) * (1.0 / 3.0);
        Vector3d q_x = FQ.col(i), q_y = n.cross(q_x);
        Vector3d q_xl = -q_x, q_xr = q_x;
        Vector3d q_yl = -q_y, q_yr = q_y;
        Vector3d q_yl_unfold = q_y, q_yr_unfold = q_y, q_xl_unfold = q_x, q_xr_unfold = q_x;
        int f;
        double tx, ty, len;
        
        f = i; len = step;
        TravelField(p, q_xl, len, f, hierarchy.mE2E, mV, mF, Nf, FQ, mQ, mN, triangle_space, &tx, &ty, &q_yl_unfold);
        
        f = i; len = step;
        TravelField(p, q_xr, len, f, hierarchy.mE2E, mV, mF, Nf, FQ, mQ, mN, triangle_space, &tx, &ty, &q_yr_unfold);
        
        f = i; len = step;
        TravelField(p, q_yl, len, f, hierarchy.mE2E, mV, mF, Nf, FQ, mQ, mN, triangle_space, &tx, &ty, &q_xl_unfold);
        
        f = i; len = step;
        TravelField(p, q_yr, len, f, hierarchy.mE2E, mV, mF, Nf, FQ, mQ, mN, triangle_space, &tx, &ty, &q_xr_unfold);
        double dSx = (q_yr_unfold - q_yl_unfold).dot(q_x) / (2.0f * step);
        double dSy = (q_xr_unfold - q_xl_unfold).dot(q_y) / (2.0f * step);
        FS.col(i) = Vector2d(dSx, dSy);
    }
    
    std::vector<double> areas(mV.cols(), 0.0);
    for (int i = 0; i < mF.cols(); ++i) {
        Vector3d p1 = mV.col(mF(1, i)) - mV.col(mF(0, i));
        Vector3d p2 = mV.col(mF(2, i)) - mV.col(mF(0, i));
        double area = p1.cross(p2).norm();
        for (int j = 0; j < 3; ++j) {
            auto index = compat_orientation_extrinsic_index_4(FQ.col(i), Nf.col(i), mQ.col(mF(j, i)), mN.col(mF(j, i)));
            double scaleX = FS.col(i).x(), scaleY = FS.col(i).y();
            if (index.first != index.second % 2) {
                std::swap(scaleX, scaleY);
            }
            if (index.second >= 2) {
                scaleX = -scaleX;
                scaleY = -scaleY;
            }
            hierarchy.mK[0].col(mF(j, i)) += area * Vector2d(scaleX, scaleY);
            areas[mF(j, i)] += area;
        }
    }
    for (int i = 0; i < mV.cols(); ++i) {
        if (areas[i] != 0)
            hierarchy.mK[0].col(i) /= areas[i];
    }
    for (int l = 0; l< hierarchy.mK.size() - 1; ++l)  {
        const MatrixXd &K = hierarchy.mK[l];
        MatrixXd &K_next = hierarchy.mK[l + 1];
        auto& toUpper = hierarchy.mToUpper[l];
        for (int i = 0; i < toUpper.cols(); ++i) {
            Vector2i upper = toUpper.col(i);
            Vector2d k0 = K.col(upper[0]);
            
            if (upper[1] != -1) {
                Vector2d k1 = K.col(upper[1]);
                k0 = 0.5 * (k0 + k1);
            }
            
            K_next.col(i) = k0;
        }
    }
}

} // namespace qflow


namespace qflow {

// Anisotropic sizing by the rule recovered from ZRemesher (engine 0x1efb00, qualified on
// 2x21,376 controlled and 7,280 natural faces): per vertex and per field axis, with base size S,
//   cap   = coefficient / kappa,          coefficient = 2*sin(3.1415/16) = 0.39017
//   floor = min(0.9*S/max_ratio, floor_factor / kappa),   floor_factor = 1.1755, max_ratio = 4
//   size  = max(min(S, cap), floor);      kappa ~ 0 keeps S
// followed by the recovered diffusion sequence (mean, 2 min sweeps, mean, 3 min, mean, 2 min, mean)
// and the ratio clamp. kappa is the normal curvature along the axis from the recovered edge-tensor
// field (signed dihedral x length x tangent dyad, clipped radius ball, feature marks; 0x1e6ef0 /
// 0x26faf0) at one radius S; native evaluates five radii from 0.33 S to 1.75 S per face and picks
// a window by direction consistency, which is not ported, nor is its coupled least-squares sizing.
// normalize_count (engineering policy, not native): rescale the base size so the expected
// face count still meets the request; native output overshoots instead.
void Parametrizer::ComputeSizeCaps(double coefficient, double max_ratio, double floor_factor, int normalize_count) {
    auto& V = hierarchy.mV[0];
    auto& N = hierarchy.mN[0];
    auto& Q = hierarchy.mQ[0];
    auto& adj = hierarchy.mAdj[0];
    auto& S = hierarchy.mS[0];
    const int n = V.cols();
    std::vector<Vector2d> kappa(n, Vector2d::Zero());
    std::vector<int> confident(n, 0);
    // Normal-cycle curvature tensor as the recovered field does it: signed dihedral x edge length x
    // edge dyads summed over the ball of radius S and divided by the ball area. The normal curvature
    // along a field axis is the quadratic form of the perpendicular in-plane direction.
    auto& F = hierarchy.mF; auto& E2E = hierarchy.mE2E;
    // Native estimates curvature on a conditioned source faired with its feature paths and
    // boundary locked (4 rounds x 3 passes), so detail finer than a quad does not drive the size
    // field. Fair a copy of the positions the same way (shrink-free Taubin steps) for the estimate only.
    // Recovered 0x26faf0 (radius field) marks: vertices on the admitted feature paths get no tensor of
    // their own, the ball walk does not continue through them, and the feature edges themselves (marked
    // to marked) never contribute, so a kept crease does not drive the size field; only the unadmitted
    // curvature beside it does. Native marks embedded guide vertices whose edge turns 20 degrees or
    // more (0x3fd6571857e74487); here those are the guide segments lying on mesh edges, plus the
    // preserved sharp edges. The same vertices stay locked in the fairing below, as native locks its
    // feature paths.
    std::vector<char> marked(n, 0);
    {
        std::vector<Vector3d> raw_normal(F.cols());
        for (int f = 0; f < F.cols(); ++f) {
            Vector3d u = V.col(F(1, f)) - V.col(F(0, f)), w = V.col(F(2, f)) - V.col(F(0, f)); Vector3d nf = u.cross(w); double l = nf.norm();
            raw_normal[f] = l > 0 ? Vector3d(nf / l) : Vector3d::Zero();
        }
        const double mark_turn = 0.3490658503988659, tolerance = 1e-6;
        int from_sharp = 0, from_guides = 0;
        for (int e = 0; e < 3 * F.cols(); ++e) {
            int o = E2E[e]; if (o < 0 || o < e) continue;
            int va = F(e % 3, e / 3), vb = F((e + 1) % 3, e / 3);
            if (e < (int)constrained_modes.size() && (constrained_modes[e] == 1 || constrained_modes[e] == 2)) {
                // A listed edge of a native mode answers to the native rule alone: a turn of 20 degrees or more.
                // (Modes 3 and 4 are preserved edges and are marked below, as preserved edges always were.)
                if (std::acos(std::max(-1.0, std::min(1.0, raw_normal[e / 3].dot(raw_normal[o / 3])))) >= mark_turn) {
                    marked[va] = marked[vb] = 1; ++from_guides;
                }
                continue;
            }
            if (e < (int)sharp_edges.size() && sharp_edges[e]) { marked[va] = marked[vb] = 1; ++from_sharp; continue; }
            if (guide_a.empty() || std::acos(std::max(-1.0, std::min(1.0, raw_normal[e / 3].dot(raw_normal[o / 3])))) < mark_turn) continue;
            Vector3d p = V.col(va), q = V.col(vb);
            for (size_t g = 0; g < guide_a.size(); ++g) {
                Vector3d d = guide_b[g] - guide_a[g]; double dd = d.squaredNorm(); if (dd <= 0) continue;
                double u = d.dot(p - guide_a[g]) / dd, v = d.dot(q - guide_a[g]) / dd;
                if (u < -tolerance || v < -tolerance || u > 1 + tolerance || v > 1 + tolerance) continue;
                if ((p - guide_a[g] - u * d).norm() > tolerance || (q - guide_a[g] - v * d).norm() > tolerance) continue;
                marked[va] = marked[vb] = 1; ++from_guides; break;
            }
        }
        printf("Size caps marks: %d feature edges (%d preserved sharp, %d guide edges turning >= 20 deg) mark %d vertices\n",
               from_sharp + from_guides, from_sharp, from_guides, (int)std::count(marked.begin(), marked.end(), 1));
    }
    MatrixXd Vs = V;
    {
        std::vector<char> locked(marked.begin(), marked.end());
        for (int e = 0; e < 3 * F.cols(); ++e)
            if (E2E[e] == -1) { locked[F(e % 3, e / 3)] = 1; locked[F((e + 1) % 3, e / 3)] = 1; }
        printf("Size caps fairing: %d of %d vertices locked\n", (int)std::count(locked.begin(), locked.end(), 1), n);
        for (int round = 0; round < 12; ++round) {
            for (double lambda : {0.5, -0.53}) {
                MatrixXd next = Vs;
                for (int i = 0; i < n; ++i) {
                    if (locked[i] || adj[i].empty()) continue;
                    Vector3d mean = Vector3d::Zero();
                    for (auto& link : adj[i]) mean += Vs.col(link.id);
                    mean /= (double)adj[i].size();
                    next.col(i) = Vs.col(i) + lambda * (mean - Vs.col(i));
                }
                Vs = next;
            }
        }
    }
    std::vector<Vector3d> face_normal(F.cols());
    for (int f = 0; f < F.cols(); ++f) {
        Vector3d a = Vs.col(F(0, f)), b = Vs.col(F(1, f)), c = Vs.col(F(2, f));
        Vector3d nf = (b - a).cross(c - a); double l = nf.norm(); face_normal[f] = l > 0 ? Vector3d(nf / l) : Vector3d::Zero();
    }
    std::vector<double> edge_turn(3 * F.cols(), 0.0);   // signed dihedral per half-edge (both halves)
    for (int e = 0; e < 3 * F.cols(); ++e) {
        int o = E2E[e]; if (o < 0 || o < e) continue;
        int f0 = e / 3, f1 = o / 3; Vector3d n0 = face_normal[f0], n1 = face_normal[f1];
        Vector3d d = Vs.col(F((e + 1) % 3, f0)) - Vs.col(F(e % 3, f0)); double dl = d.norm(); if (dl <= 0) continue;
        double angle = std::atan2(n0.cross(n1).dot(d / dl), n0.dot(n1));
        edge_turn[e] = angle; edge_turn[o] = angle;
    }
    std::vector<std::vector<int>> vertex_faces(n);
    for (int f = 0; f < F.cols(); ++f) for (int k = 0; k < 3; ++k) vertex_faces[F(k, f)].push_back(f);
    const double radius = hierarchy.mScale, radius2 = radius * radius;
    for (int i = 0; i < n; ++i) {
        if (marked[i]) continue;
        Vector3d p = Vs.col(i), nn = N.col(i).normalized();
        Vector3d q = Q.col(i); q = (q - nn * nn.dot(q));
        if (q.norm() < 1e-12) continue;
        q.normalize(); Vector3d t = nn.cross(q);
        std::vector<int> ball{i}; std::vector<int> frontier{i}; std::set<int> seen{i};
        while (!frontier.empty() && ball.size() < 256) {
            std::vector<int> next;
            for (int u : frontier) for (auto& link : adj[u]) {
                int w = link.id; if (seen.count(w)) continue; seen.insert(w);
                if ((Vs.col(w) - p).squaredNorm() <= radius2) { ball.push_back(w); if (!marked[w]) next.push_back(w); }
            }
            frontier = next;
        }
        std::set<int> faces; for (int v : ball) for (int f : vertex_faces[v]) faces.insert(f);
        Matrix3d T = Matrix3d::Zero(); int edges = 0;
        for (int f : faces) for (int k = 0; k < 3; ++k) {
            int e = 3 * f + k, o = E2E[e]; if (o < 0 || o < e) continue;
            if (marked[F(k, f)] && marked[F((k + 1) % 3, f)]) continue;
            Vector3d a = Vs.col(F(k, f)), b = Vs.col(F((k + 1) % 3, f)); double da = (a - p).norm(), db = (b - p).norm();
            double inside = (da <= radius && db <= radius) ? 1.0 : (da <= radius) ? (radius - da) / std::max(1e-30, db - da) : (db <= radius) ? (radius - db) / std::max(1e-30, da - db) : 0.0;
            if (inside <= 0) continue;
            Vector3d d = b - a; double dl = d.norm(); if (dl <= 0) continue; d /= dl;
            T += edge_turn[e] * dl * inside * (d * d.transpose()); ++edges;
        }
        if (edges < 3) continue;
        T /= 3.14159265358979 * radius2;
        kappa[i] = Vector2d(std::fabs(t.dot(T * t)), std::fabs(q.dot(T * q)));   // along q: bending across edges parallel to t
        confident[i] = 1;
    }
    double base = hierarchy.mScale;
    std::vector<Vector2d> ratio(n, Vector2d(1, 1));
    auto sizes_for = [&](double S0) {
        double lower = 0.9 * S0 / max_ratio;
        for (int i = 0; i < n; ++i) {
            for (int a = 0; a < 2; ++a) {
                double k = confident[i] ? kappa[i][a] : 0.0;
                double size = S0;
                if (k * S0 > 1e-6) {
                    double cap = coefficient / k, floor_v = std::min(lower, floor_factor / k);
                    size = std::max(std::min(S0, cap), floor_v);
                }
                ratio[i][a] = size / S0;
            }
        }
    };
    auto neighbor_ratio = [&](int i, int j) {
        Vector2d r = ratio[j];
        auto index = compat_orientation_extrinsic_index_4(Q.col(i), N.col(i), Q.col(j), N.col(j));
        if (index.first % 2 != index.second % 2) std::swap(r[0], r[1]);
        return r;
    };
    // Native runs its sweeps (mean, 2 min, mean, 3 min, mean, 2 min, mean) on a mesh conditioned to
    // edges of sqrt(A / max(3000, faces)); each min step spreads about half such an edge. This mesh is
    // not conditioned uniformly, so each group of min steps is one ball-minimum over that distance and
    // each mean is a ball-mean over one native edge; the minimum spreads the native 3.5 edges in total.
    double faces_requested = surface_area / (base * base);
    double budget = faces_requested < 3000 ? 3000 : faces_requested < 8000 ? faces_requested : faces_requested < 15000 ? 8000 + (faces_requested - 8000) * 4 / 7 : 12000;
    double native_edge = std::sqrt(surface_area / budget);
    auto ball_of = [&](int i, double R) {
        std::vector<int> ball{i}; std::vector<int> frontier{i}; std::set<int> seen{i}; double R2 = R * R;
        while (!frontier.empty() && ball.size() < 512) {
            std::vector<int> next;
            for (int u : frontier) for (auto& link : adj[u]) {
                int w = link.id; if (seen.count(w)) continue; seen.insert(w);
                if ((V.col(w) - V.col(i)).squaredNorm() <= R2) { ball.push_back(w); next.push_back(w); }
            }
            frontier = next;
        }
        return ball;
    };
    std::string sequence = "a2a3a2a";
    auto diffuse = [&]() {
        for (char step : sequence) {
            double R = step == 'a' ? native_edge : (step - '0') * 0.5 * native_edge;
            std::vector<Vector2d> next(n);
            for (int i = 0; i < n; ++i) {
                Vector2d acc = ratio[i]; int count = 1;
                for (int j : ball_of(i, R)) {
                    if (j == i) continue;
                    Vector2d r = neighbor_ratio(i, j);
                    if (step == 'a') { acc += r; ++count; }
                    else { acc[0] = std::min(acc[0], r[0]); acc[1] = std::min(acc[1], r[1]); }
                }
                next[i] = (step == 'a') ? Vector2d(acc / count) : acc;
            }
            ratio = next;
        }
        double low = 0.9 / max_ratio;
        for (int i = 0; i < n; ++i)
            for (int a = 0; a < 2; ++a) ratio[i][a] = std::min(1.0, std::max(low, ratio[i][a]));
    };
    double scale_now = base;
    for (int iteration = 0; iteration < (normalize_count ? 3 : 1); ++iteration) {
        sizes_for(scale_now);
        diffuse();
        if (!normalize_count) break;
        // Expected faces = target * area-weighted mean of 1/(r0*r1); enlarge the base to compensate.
        double num = 0, den = 0;
        for (int i = 0; i < n; ++i) { double a = hierarchy.mA[0][i]; num += a / (ratio[i][0] * ratio[i][1]); den += a; }
        double density = num / den;
        scale_now = std::sqrt(hierarchy.mScale * hierarchy.mScale * density);
    }
    double rmin = 1, rmax = 0;
    {   // diagnostics: area-weighted distribution of the smaller axis ratio and of the raw curvature
        std::vector<std::pair<double,double>> rows; double total = 0, density = 0, capped = 0;
        for (int i = 0; i < n; ++i) { double a = hierarchy.mA[0][i]; rows.push_back({std::min(ratio[i][0], ratio[i][1]), a}); total += a; density += a / (ratio[i][0] * ratio[i][1]); if (std::min(ratio[i][0], ratio[i][1]) < 0.999) capped += a; }
        std::sort(rows.begin(), rows.end()); double acc = 0; double p10 = 0, p50 = 0, p90 = 0;
        for (auto& r : rows) { acc += r.second; if (!p10 && acc >= 0.1 * total) p10 = r.first; if (!p50 && acc >= 0.5 * total) p50 = r.first; if (!p90 && acc >= 0.9 * total) p90 = r.first; }
        std::vector<double> ks; for (int i = 0; i < n; ++i) ks.push_back(std::max(kappa[i][0], kappa[i][1]) * base);
        std::sort(ks.begin(), ks.end());
        printf("Size caps diagnostics: min-axis ratio p10 %g p50 %g p90 %g, capped area %.0f%%, expected count x%.2f, kappa*S median %g p90 %g (cap below S when kappa*S > %g)\n",
               p10, p50, p90, 100 * capped / total, density / total, ks[ks.size() / 2], ks[ks.size() * 9 / 10], coefficient);
    }
    for (int i = 0; i < n; ++i) { S.col(i) = ratio[i]; rmin = std::min(rmin, std::min(ratio[i][0], ratio[i][1])); rmax = std::max(rmax, std::max(ratio[i][0], ratio[i][1])); }
    if (const char* dump = getenv("QF_SIZE_DUMP")) {
        FILE* out = fopen(dump, "w");
        if (out) { for (int i = 0; i < n; ++i) fprintf(out, "%g %g %g %g %g %g %g %g\n", V(0, i), V(1, i), V(2, i), ratio[i][0], ratio[i][1], kappa[i][0], kappa[i][1], hierarchy.mA[0][i]); fclose(out); }
    }
    printf("Size caps: ratio range [%g, %g], confident %d / %d vertices (%d marked on features), sweeps %s, base scale %g -> %g\n", rmin, rmax,
           (int)std::count(confident.begin(), confident.end(), 1), n, (int)std::count(marked.begin(), marked.end(), 1), sequence.c_str(), base, scale_now);
    hierarchy.mScale = scale_now;
    for (int l = 0; l < (int)hierarchy.mS.size() - 1; ++l) {
        const MatrixXd& Sl = hierarchy.mS[l]; MatrixXd& S_next = hierarchy.mS[l + 1]; auto& toUpper = hierarchy.mToUpper[l];
        for (int i = 0; i < toUpper.cols(); ++i) {
            Vector2i upper = toUpper.col(i); Vector2d q0 = Sl.col(upper[0]);
            if (upper[1] != -1) q0 = (q0 + Sl.col(upper[1])) * 0.5;
            S_next.col(i) = q0;
        }
    }
}

}  // namespace qflow
