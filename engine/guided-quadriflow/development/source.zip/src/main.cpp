#include <cmath>
#include "config.hpp"
#include "field-math.hpp"
#include "optimizer.hpp"
#include "parametrizer.hpp"
#include "guide-constraints.hpp"
#include <stdlib.h>

#ifdef WITH_CUDA
#include <cuda_runtime.h>
#endif

using namespace qflow;

Parametrizer field;

int main(int argc, char** argv) {
    setbuf(stdout, NULL);

#ifdef WITH_CUDA
    cudaFree(0);
#endif
    int t1, t2;
    std::string input_obj, output_obj, guide_file, field_file;
    std::string registered_file, registered_output;
    double guide_width=.5, orientation_weight=1., position_weight=0.;
    bool embedded_guides=false;
    int faces = -1;
    for (int i = 0; i < argc; ++i) {
        if (strcmp(argv[i], "-f") == 0) {
            sscanf(argv[i + 1], "%d", &faces);
        } else if (strcmp(argv[i], "-i") == 0) {
            input_obj = argv[i + 1];
        } else if (strcmp(argv[i], "-o") == 0) {
            output_obj = argv[i + 1];
        } else if (strcmp(argv[i], "-sharp") == 0) {
            field.flag_preserve_sharp = 1;
        } else if (strcmp(argv[i], "-boundary") == 0) {
            field.flag_preserve_boundary = 1;
        } else if (strcmp(argv[i], "-adaptive") == 0) {
            field.flag_adaptive_scale = 1;
        } else if (strcmp(argv[i], "-size-caps") == 0) {
            field.flag_adaptive_scale = 1;
            field.flag_size_caps = 1;
        } else if (strcmp(argv[i], "-size-caps-exact") == 0) {
            field.flag_adaptive_scale = 1;
            field.flag_size_caps = 2;
        } else if (strcmp(argv[i], "-mcf") == 0) {
            field.flag_minimum_cost_flow = 1;
        } else if (strcmp(argv[i], "-sat") == 0) {
            field.flag_aggresive_sat = 1;
        } else if (strcmp(argv[i], "-seed") == 0) {
            field.hierarchy.rng_seed = atoi(argv[i + 1]);
        } else if (strcmp(argv[i], "-guides") == 0) {
            guide_file=argv[i+1];
        } else if (strcmp(argv[i], "-field") == 0) {
            field_file=argv[i+1];
        } else if (strcmp(argv[i], "-guide-width") == 0) {
            guide_width=atof(argv[i+1]);
        } else if (strcmp(argv[i], "-orientation-weight") == 0) {
            orientation_weight=atof(argv[i+1]);
        } else if (strcmp(argv[i], "-position-weight") == 0) {
            position_weight=atof(argv[i+1]);
        } else if (strcmp(argv[i], "-embedded-guides") == 0) {
            embedded_guides=true;
        } else if (strcmp(argv[i], "-project-guide-positions") == 0) {
            field.project_guide_positions=true;
        } else if (strcmp(argv[i], "-registered-features") == 0) {
            registered_file=argv[i+1];
        } else if (strcmp(argv[i], "-registered-output") == 0) {
            registered_output=argv[i+1];
        }
    }
    std::string registered_stage="source-registration";
    try {
    printf("%d %s %s\n", faces, input_obj.c_str(), output_obj.c_str());
    if (input_obj.size() >= 1) {
        field.Load(input_obj.c_str());
    } else {
        assert(0);
        // field.Load((std::string(DATA_PATH) + "/fertility.obj").c_str());
    }

    if (!registered_file.empty()) field.LoadRegisteredFeatures(registered_file);
    printf("Initialize...\n");
    t1 = GetCurrentTime64();
    field.Initialize(faces);
    t2 = GetCurrentTime64();
    printf("Use %lf seconds\n", (t2 - t1) * 1e-3);

    if (field.flag_preserve_boundary) {
        printf("Add boundary constrains...\n");
        Hierarchy& mRes = field.hierarchy;
        mRes.clearConstraints();
        for (uint32_t i = 0; i < 3 * mRes.mF.cols(); ++i) {
            if (mRes.mE2E[i] == -1) {
                uint32_t i0 = mRes.mF(i % 3, i / 3);
                uint32_t i1 = mRes.mF((i + 1) % 3, i / 3);
                Vector3d p0 = mRes.mV[0].col(i0), p1 = mRes.mV[0].col(i1);
                Vector3d edge = p1 - p0;
                if (edge.squaredNorm() > 0) {
                    edge.normalize();
                    mRes.mCO[0].col(i0) = p0;
                    mRes.mCO[0].col(i1) = p1;
                    mRes.mCQ[0].col(i0) = mRes.mCQ[0].col(i1) = edge;
                    mRes.mCQw[0][i0] = mRes.mCQw[0][i1] = mRes.mCOw[0][i0] = mRes.mCOw[0][i1] =
                        1.0;
                }
            }
        }
        mRes.propagateConstraints();
    }

    std::vector<int> guide_owners;
    if (!guide_file.empty()) guide_owners=attach_guides(field,guide_file,guide_width,orientation_weight,position_weight,embedded_guides);
    field.ConstrainRegisteredOrientations();
    printf("Solve Orientation Field...\n");
    t1 = GetCurrentTime64();

    Optimizer::optimize_orientations(field.hierarchy);
    field.ComputeOrientationSingularities();
    t2 = GetCurrentTime64();
    printf("Use %lf seconds\n", (t2 - t1) * 1e-3);

    if (field.flag_adaptive_scale == 1 && !field.flag_size_caps) {
        printf("Estimate Slop...\n");
        t1 = GetCurrentTime64();
        field.EstimateSlope();
        t2 = GetCurrentTime64();
        printf("Use %lf seconds\n", (t2 - t1) * 1e-3);
    }
    printf("Solve for scale...\n");
    t1 = GetCurrentTime64();
    if (field.flag_size_caps)
        field.ComputeSizeCaps(2.0 * sin(3.1415 / 16.0), 4.0, 1.175540566444397, field.flag_size_caps == 2);
    else
        Optimizer::optimize_scale(field.hierarchy, field.rho, field.flag_adaptive_scale);
    field.flag_adaptive_scale = 1;
    t2 = GetCurrentTime64();
    printf("Use %lf seconds\n", (t2 - t1) * 1e-3);

    printf("Solve for position field...\n");
    t1 = GetCurrentTime64();
    Optimizer::optimize_positions(field.hierarchy, field.flag_adaptive_scale);

    field.ComputePositionSingularities();
    if (!field_file.empty()) dump_guide_field(field,guide_owners,field_file);
    t2 = GetCurrentTime64();
    printf("Use %lf seconds\n", (t2 - t1) * 1e-3);
    t1 = GetCurrentTime64();
    printf("Solve index map...\n");
    registered_stage="integer-registration";
    field.ComputeIndexMap();
    t2 = GetCurrentTime64();
    printf("Indexmap Use %lf seconds\n", (t2 - t1) * 1e-3);
    printf("Writing the file...\n");

    if (output_obj.size() < 1) {
        assert(0);
        // field.OutputMesh((std::string(DATA_PATH) + "/result.obj").c_str());
    } else {
        field.OutputMesh(output_obj.c_str());
    }
    if (!registered_file.empty()) {
        if (registered_output.empty()) registered_output=output_obj+".features.json";
        if (!field.OutputRegisteredFeatures(registered_output)) return 3;
    }
    printf("finish...\n");
    //	field.LoopFace(2);
    return 0;
    } catch(const std::exception& error) {
        fprintf(stderr,"Registered layout failed at %s: %s\n",registered_stage.c_str(),error.what());
        if(!registered_file.empty()) {
            if(registered_output.empty())registered_output=output_obj+".features.json";
            std::ofstream failure(registered_output);
            failure<<"{\n  \"schema\": 1, \"passed\": false, \"constructionCompleted\": false,\n  \"error\": "<<std::quoted(error.what())
                   <<",\n  \"stage\": "<<std::quoted(registered_stage)<<", \"registeredPathCount\": "<<field.registered_paths.size()<<",\n  \"paths\": []\n}\n";
        }
        return 3;
    }
}
